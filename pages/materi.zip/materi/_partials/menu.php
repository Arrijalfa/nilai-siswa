<div class="card card-default">
  <div class="card-body">
    <div class="row">
      <div class="col-auto mt-2">
        <a href="create.php" class="btn btn-primary">
          <i class="fas fa-plus"></i> Tambah
        </a>
      </div>
      <div class="col-auto mt-2">
        <a href="#" class="btn btn-primary" onclick="window.location.reload();">
          <i class="fas fa-sync-alt"></i> Refresh
        </a>
      </div>
    </div>
  </div>
</div>
<br>
